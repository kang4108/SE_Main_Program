from flask import Flask, render_template, request, flash, redirect, url_for
import requests
import os
import platform

app = Flask(__name__)
app.secret_key = 'thisisjustarandomstring'

WELCOME_SERVICE_HOST = 'localhost'
WELCOME_SERVICE_PORT = 5051

@app.route('/', methods=['POST', 'GET'])
def index():
    if request.method == "POST":
        if request.form['submit_button'] == 'Test connection':
            # Adjusted this line for cross-platform compatibility
            param = '-n' if platform.system().lower()=='windows' else '-c'
            ret = os.system(f'ping {param} 1 {WELCOME_SERVICE_HOST}')
            if ret == 0:
                flash('The test was successful', "green")
                return redirect(url_for("test"))
            else:
                flash('The test failed. Welcome-service is not UP', "red")
                return redirect(url_for("index"))

        elif request.form['submit_button'] == 'Reset':
            return redirect(url_for("index"))
        else:
            pass
    return render_template('index.html')

@app.route('/test', methods=['POST', 'GET'])
def test():
    if request.method == "POST":
        if request.form['submit_button'] == 'Reset':
            return redirect(url_for("index"))
        elif request.form['submit_button'] == 'Get Message':
            data = requests.get(f'http://{WELCOME_SERVICE_HOST}:{WELCOME_SERVICE_PORT}').json()
            flash(str(data), "green")
            return redirect(url_for('test'))
        else:
            pass
    return render_template('test_service.html')

if __name__ == '__main__':
    app.run(debug=True, port=5050, host="0.0.0.0")
